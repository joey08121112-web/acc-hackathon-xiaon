import {
  correct,
  dimensions,
  getTask,
  normalize,
  tasks,
  type Dimension,
} from "../shared/task-bank";
export const PROGRESS_KEY = "xiaon-progress-v1",
  MEMORY_KEY = "xiaon-memory-v1";
export type Attempt = {
  id: string;
  value: string;
  correct: boolean;
  hinted: boolean;
  time: string;
};
export type RecordItem = {
  id: string;
  attempts: Attempt[];
  hint: boolean;
  paused: boolean;
  draft: string;
};
export type Memory = {
  id: string;
  category: "你告诉小N的" | "学习过程中记录的" | "目前的学习观察";
  text: string;
  source: string;
  time: string;
  active: boolean;
};
export type State = {
  version: 1;
  onboarded: boolean;
  onboardStep: number;
  age: string;
  grade: string;
  book: string;
  necessary: boolean;
  guardian: "none" | "pending" | "complete" | "failed" | "cancelled";
  longMemory: boolean;
  research: boolean;
  rest: boolean;
  questionInvitePaused: boolean;
  safety: boolean;
  tab: string;
  page: string;
  activeTask: string | null;
  records: Record<string, RecordItem>;
  calcSeen: string[];
  plan: "none" | "accepted" | "lighter" | "rescheduled" | "deferred";
  planDate: string;
  helpContact: string;
  helpStatus: "none" | "confirm" | "sending" | "sent" | "failed";
  unsafe: boolean;
  rights: "none" | "verify" | "processing" | "result";
  rightsScope: string;
  uploadText: string;
  uploadConfirmed: boolean;
  storageNotice: string;
  statusTrail: Record<string, { status: string; time: string }[]>;
  /** 从设置重新体验首次进入时备份原选择；中途退出就恢复，走完就清掉。 */
  introBackup?: Pick<State, "age" | "grade" | "book" | "necessary" | "guardian" | "research">;
};
export function initial(): State {
  return {
    version: 1,
    onboarded: false,
    onboardStep: 0,
    age: "under14",
    grade: "七年级",
    book: "人教版",
    necessary: false,
    guardian: "none",
    longMemory: false,
    research: false,
    rest: false,
    questionInvitePaused: false,
    safety: false,
    tab: "小N",
    page: "home",
    activeTask: null,
    records: {},
    calcSeen: [],
    plan: "none",
    planDate: "",
    helpContact: "我信任的老师",
    helpStatus: "none",
    unsafe: false,
    rights: "none",
    rightsScope: "学习目标与任务记录",
    uploadText: "3x − (2x − 5)",
    uploadConfirmed: false,
    storageNotice: "",
    statusTrail: {},
  };
}
export function hydrate(raw: string | null): State {
  try {
    if (!raw) return initial();
    const parsed = JSON.parse(raw);
    if (parsed.version !== 1) return initial();
    const s = { ...initial(), ...parsed };
    // 2026-11-21 删掉整套本地聊天状态机（生产路径走服务端）。旧版本存下来的聊天字段读进来就丢掉，
    // 别让内存里留着「看起来还在用、其实没人写」的状态。
    delete s.chat;delete s.chatDraft;delete s.chatStatus;delete s.pendingChat;
    if (s.helpStatus === "sending") s.helpStatus = "failed";
    if (s.rights === "processing") s.rights = "verify";
    return s;
  } catch {
    return {
      ...initial(),
      storageNotice: "本机进度无法读取，已进入新的演示。",
    };
  }
}
export type Action =
  | { type: "patch"; patch: Partial<State> }
  | { type: "open-task"; id: string }
  | { type: "draft"; id: string; value: string }
  | { type: "hint"; id: string }
  | { type: "attempt"; taskId: string; id: string; value: string; time: string }
  | { type: "pause"; id: string }
  | { type: "reset" };
export function reducer(s: State, a: Action): State {
  switch (a.type) {
    case "reset":
      return initial();
    case "patch":
      return { ...s, ...a.patch };
    case "open-task": {
      if (s.safety) return s;
      const t = getTask(a.id);
      if (!t) return s;
      if (
        t.dim === "计算" &&
        !s.calcSeen.includes(t.id) &&
        s.calcSeen.length >= 10
      )
        return s;
      return {
        ...s,
        rest: false,
        questionInvitePaused: false,
        activeTask: t.id,
        page: "task",
        calcSeen:
          t.dim === "计算" && !s.calcSeen.includes(t.id)
            ? [...s.calcSeen, t.id]
            : s.calcSeen,
        records: {
          ...s.records,
          [t.id]: {
            ...(s.records[t.id] || {
              id: t.id,
              attempts: [],
              hint: false,
              draft: "",
            }),
            paused: false,
          },
        },
      };
    }
    case "draft":
      return {
        ...s,
        records: {
          ...s.records,
          [a.id]: { ...s.records[a.id], draft: a.value },
        },
      };
    case "hint":
      return {
        ...s,
        records: { ...s.records, [a.id]: { ...s.records[a.id], hint: true } },
      };
    case "pause":
      return {
        ...s,
        page: "home",
        tab: "小N",
        records: { ...s.records, [a.id]: { ...s.records[a.id], paused: true } },
      };
    case "attempt": {
      const r = s.records[a.taskId];
      if (
        s.safety ||
        !r ||
        !a.value.trim() ||
        r.attempts.some((x) => x.id === a.id)
      )
        return s;
      const records = {
        ...s.records,
        [a.taskId]: {
          ...r,
          attempts: [
            ...r.attempts,
            {
              id: a.id,
              value: a.value,
              correct: correct(getTask(a.taskId), a.value),
              hinted: r.hint,
              time: a.time,
            },
          ],
        },
      };
      return { ...s, records, statusTrail: withTrail(s.statusTrail, records, a.time) };
    }
  }
}
export type Observation = {
  dim: Dimension;
  status: string;
  finding: string;
  basis: RecordItem[];
  next: string;
};
function statusFor(basis: RecordItem[]): string {
  const independent = basis.filter(
    (r) => r.attempts[0]?.correct && !r.attempts[0]?.hinted,
  );
  const hinted = basis.filter((r) =>
    r.attempts.some((a) => a.correct && a.hinted),
  );
  return independent.length >= 2
    ? "多次独立完成"
    : independent.length
      ? "本次独立完成"
      : hinted.length
        ? "提示下完成"
        : basis.length
          ? "需要继续观察"
          : "尚未观察";
}
function withTrail(
  trail: State["statusTrail"],
  records: State["records"],
  time: string,
): State["statusTrail"] {
  const next = { ...trail };
  for (const dim of dimensions) {
    const basis = Object.values(records).filter(
      (r) => getTask(r.id).dim === dim && r.attempts.length,
    );
    if (!basis.length) continue;
    const status = statusFor(basis);
    const arr = next[dim] || [];
    if (arr.at(-1)?.status !== status)
      next[dim] = [...arr, { status, time }];
  }
  return next;
}
export function observations(s: State): Observation[] {
  return dimensions.map((dim) => {
    const basis = Object.values(s.records).filter(
      (r) => getTask(r.id).dim === dim && r.attempts.length,
    );
    const independent = basis.filter(
      (r) => r.attempts[0]?.correct && !r.attempts[0]?.hinted,
    );
    const hinted = basis.filter((r) =>
      r.attempts.some((a) => a.correct && a.hinted),
    );
    const status = statusFor(basis);
    const signErrors = basis.filter((r) => {
      const t = getTask(r.id),
        wrongSign = t.answer[0].replace("+", "-");
      return (
        t.dim === "计算" &&
        r.attempts.some(
          (a) =>
            !a.correct && normalize(a.value).split("=").at(-1) === wrongSign,
        )
      );
    });
    let finding = !basis.length
      ? "还没有足够的作答依据。未开始或暂停，都不代表能力弱。"
      : independent.length
        ? `这次有 ${independent.length} 道不同的题，你在首次尝试时没有使用提示就完成了。`
        : hinted.length
          ? "你在提示的帮助下完成了答案。还需要用一道新题，看看能否独立完成。"
          : "这次作答还没有完成正确解答。我们需要继续了解具体步骤。";
    if (dim === "计算" && signErrors.length)
      finding = `这次 ${signErrors.length} 道题中，出现了与去括号时漏改符号一致的结果，具体步骤仍需核对。${independent.length ? "另有题目留下首次独立完成记录。" : "可以先一起观察这个小环节。"}`;
    return {
      dim,
      status,
      finding,
      basis,
      next:
        dim === "计算"
          ? "在新题中先圈出括号前的符号，再逐项去括号。"
          : "换一个同类情境，看看是否仍能独立解释自己的想法。",
    };
  });
}
export function taskStatus(s: State, id: string) {
  const r = s.records[id];
  return !r
    ? "未开始"
    : r.attempts.some((a) => a.correct)
      ? "完成"
      : r.paused
        ? "暂未完成"
        : "进行中";
}
export function memoryAfter(s: State, items: Memory[], item: Memory): Memory[] {
  return s.longMemory && !items.some((m) => m.id === item.id)
    ? [...items, item]
    : items;
}
export const timeLabel = () =>
  new Date().toLocaleString("zh-CN", {
    timeZone: "Asia/Shanghai",
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
export type PlanTask = {
  day: string;
  title: string;
  note: string;
  mins: number;
  taskId?: string;
};
export type PlanDraft = {
  eyebrow: string;
  goal: string;
  note: string;
  tasks: PlanTask[];
};
export function nextNewCalcId(s: State): string {
  return (
    [
      "transfer",
      ...tasks.filter((t) => t.id.startsWith("calc-")).map((t) => t.id),
    ].find((id) => !s.calcSeen.includes(id)) || "transfer"
  );
}
// 周计划按计算维观察结果分流：有符号错误时先补这个环节，
// 已能独立完成时转向巩固与检验，避免给所有学生同一份固定建议。
export function planDraft(s: State): PlanDraft {
  const calc = observations(s)[2];
  if (calc.status === "多次独立完成")
    return {
      eyebrow: "根据当前计算任务记录",
      goal: "把去括号的方法用活",
      note: "你已经在不同的题里独立完成。这周试试把方法讲清楚，再编一道题考考自己。",
      tasks: [
        {
          day: "第 1 次",
          title: "再检验一道同类新题",
          note: "约 3 分钟 · 保持不提示",
          mins: 3,
          taskId: nextNewCalcId(s),
        },
        {
          day: "第 2 次",
          title: "自己编一道去括号题",
          note: "约 3 分钟 · 写出题目和解答",
          mins: 3,
        },
      ],
    };
  if (calc.status === "本次独立完成")
    return {
      eyebrow: "根据当前计算任务记录",
      goal: "站稳去括号这一步",
      note: "这次你独立完成了。再换一道新题，看看是不是每次都稳。",
      tasks: [
        {
          day: "第 1 次",
          title: "换一道同类新题，自己试试",
          note: "约 3 分钟 · 优先不提示",
          mins: 3,
          taskId: nextNewCalcId(s),
        },
        {
          day: "第 2 次",
          title: "回看方法，复述关键一步",
          note: "约 2 分钟",
          mins: 2,
        },
      ],
    };
  return {
    eyebrow: calc.basis.length
      ? "根据当前计算任务记录"
      : "尚无作答依据 · 可选建议目标",
    goal: "看清括号前的负号",
    note: "先圈符号，再逐项去括号。用新题看看，能不能自己处理好。",
    tasks: [
      {
        day: "第 1 次",
        title: "一起观察一个括号",
        note: "约 3 分钟 · 原题尝试与提示",
        mins: 3,
        taskId: "bracket",
      },
      {
        day: "第 2 次",
        title: "换一道同类新题",
        note: "约 3 分钟 · 优先自己试试",
        mins: 3,
        taskId: "transfer",
      },
      {
        day: "第 3 次",
        title: "回看方法，整理小发现",
        note: "约 2 分钟 · 复述关键步骤",
        mins: 2,
      },
    ],
  };
}
