import { useEffect, useSyncExternalStore } from 'react';
import { apiBlob } from '../agent-client';
import { fetchJson } from '../agent-client/http';
import { CLIPS, clipsOf, clipUrl, type ClipGroup } from '../../shared/voice-clips';
import { splitSentences } from './sentences';
import { audioEnvelope } from './envelope';
/**
 * One shared audio player for the whole app. `phase` reflects the real <audio> element, so the pet only
 * "speaks" while sound is actually playing. Text is always shown; sound is an optional extra.
 */
export type VoiceState = { available: boolean; asr: boolean; enabled: boolean; phase: 'idle' | 'loading' | 'playing'; error: string };
const KEY = 'xiaon-voice-on';
const SILENT = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=';
// A talking pet is the product's main interaction, so sound starts on; the student can switch it off and that choice is kept.
const readEnabled = () => { try { return localStorage.getItem(KEY) !== 'false'; } catch { return true; } };
let state: VoiceState = { available: false, asr: false, enabled: readEnabled(), phase: 'idle', error: '' };
const listeners = new Set<() => void>();
const set = (patch: Partial<VoiceState>) => { state = { ...state, ...patch }; listeners.forEach(l => l()); };
let audio: HTMLAudioElement | null = null, generation = 0, controller: AbortController | null = null, objectUrl = '', kind: 'filler' | 'speech' | null = null, unlocked = false, probed = false, speakOwner = 0;
const lastClip: Partial<Record<ClipGroup, string>> = {};
// Short reactions can be cut off by the next touch; only real replies (and the greeting/error lines) are never talked over.
const INTERRUPTIBLE = new Set<ClipGroup>(['think', 'long', 'poke', 'belly', 'leaf', 'hand', 'pat', 'dizzy', 'sleepy', 'retry']);
// While a speak() pipeline owns this generation, the gap between two sentences is not "playback ended".
const speakIdle = () => { if (speakOwner === generation) return; kind = null; set({ phase: 'idle' }); };

/** Decode a copy for animation without rerouting, delaying, or changing audio playback. */
const levelListeners=new Set<(v:number)=>void>();
let envelope:Float32Array|null=null,meterTicket=0,meterFrame=0;
const emitLevel=(v:number)=>levelListeners.forEach(fn=>fn(v));
export const onVoiceLevel=(fn:(v:number)=>void)=>{levelListeners.add(fn);return()=>{levelListeners.delete(fn);};};
function stopMeter(){if(meterFrame)cancelAnimationFrame(meterFrame);meterFrame=0;emitLevel(0);}
function startMeter(){
 stopMeter();if(typeof requestAnimationFrame!=='function')return;
 const tick=()=>{if(!audio||audio.paused)return;emitLevel(envelope?.[Math.floor(audio.currentTime*40)]??0);meterFrame=requestAnimationFrame(tick);};
 meterFrame=requestAnimationFrame(tick);
}
function prepareMeter(blob:Blob,gen:number){
 const ticket=++meterTicket;envelope=null;
 if(typeof window==='undefined')return;
 const Offline=window.OfflineAudioContext??(window as unknown as {webkitOfflineAudioContext?:typeof OfflineAudioContext}).webkitOfflineAudioContext;
 if(!Offline)return;
 void blob.arrayBuffer().then(bytes=>new Offline(1,1,24000).decodeAudioData(bytes)).then(buffer=>{
  if(ticket===meterTicket&&gen===generation)envelope=audioEnvelope(buffer.getChannelData(0),buffer.sampleRate);
 }).catch(()=>{/* Animation can be unavailable without failing speech. */});
}

function player() {
 if (audio) return audio;
 audio = new Audio();
 audio.preload = 'auto';
 audio.addEventListener('playing', () => { if (audio && audio.src.startsWith('data:')) return; set({ phase: 'playing', error: '' }); startMeter(); });
 const idle = () => { if (audio && audio.src.startsWith('data:')) return; stopMeter(); speakIdle(); };
 audio.addEventListener('ended', idle); audio.addEventListener('pause', idle);
 audio.addEventListener('error', () => { if (kind===null || (audio && audio.src.startsWith('data:'))) return; kind = null; stopMeter(); set({ phase: 'idle', error: '声音没能播放，文字还在。' }); });
 return audio;
}
const release = () => { if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = ''; } };
async function waitForFiller() {
 const a = player();
 if (kind !== 'filler' || a.paused) return;
 await new Promise<void>(resolve => { const done = () => { clearTimeout(t); a.removeEventListener('ended', done); a.removeEventListener('pause', done); resolve(); }; const t = setTimeout(done, 3000); a.addEventListener('ended', done); a.addEventListener('pause', done); });
}
async function play(url: string, gen: number, as: 'filler' | 'speech'): Promise<boolean> {
 const a = player();
 if (gen !== generation) return false;
 a.src = url; kind = as;
 try { await a.play(); return true; } catch { kind = null; set({ phase: 'idle', error: '浏览器没有允许自动发声，点一下「朗读」或小N即可。文字都在。' }); return false; }
}
/** Resolves when the sentence that is playing now is over (finished, paused or broken), so the queue can go on. */
function waitEnded(): Promise<void> {
 const a = player();
 return new Promise<void>(resolve => { const done = () => { clearTimeout(t); a.removeEventListener('ended', done); a.removeEventListener('pause', done); a.removeEventListener('error', done); resolve(); }; const t = setTimeout(done, 90000); a.addEventListener('ended', done); a.addEventListener('pause', done); a.addEventListener('error', done); });
}
export const voice = {
 /** Call inside a click handler so later automatic playback is allowed by the browser. */
 unlock() {
  if (unlocked) return; unlocked = true;
  const a = player();
  if (a.paused && !a.src) { a.src = SILENT; a.play().then(() => { if (a.src === SILENT) a.pause(); }).catch(() => { unlocked = false; }); }
 },
 stop() { meterTicket++;envelope=null;stopMeter();generation++; controller?.abort(); controller = null; kind = null; if (audio) audio.pause(); release(); set({ phase: 'idle', error: '' }); },
 setEnabled(on: boolean) { try { localStorage.setItem(KEY, String(on)); } catch { /* storage unavailable */ } set({ enabled: on }); if (!on) voice.stop(); },
 /** A fixed pre-recorded line, instant (no network synthesis). */
 playClip(target: ClipGroup | string) {
  if (!state.available) return;
  const byId = CLIPS.find(c => c.id === target);
  const group = (byId?.group ?? target) as ClipGroup;
  const pool = clipsOf(group), choices = pool.filter(c => c.id !== lastClip[group]), pick = byId ?? (choices.length ? choices : pool)[Math.floor(Math.random() * (choices.length || pool.length))];
  if (!pick) return; lastClip[group] = pick.id;
  voice.unlock();
  if (kind === 'speech') return; // never talk over a reply
  const gen = ++generation; meterTicket++;envelope=null;stopMeter();controller?.abort(); controller = null; release();
  return play(clipUrl(pick.id), gen, INTERRUPTIBLE.has(group) ? 'filler' : 'speech');
 },
 playClipIfEnabled(group: ClipGroup | string) { if (state.enabled) return voice.playClip(group); },
 /** Synthesize and play reply text sentence by sentence: the first words are heard as soon as sentence one is
  *  synthesized, the next sentence is prefetched while the current one plays, and the queue stays strictly ordered.
  *  A pre-recorded "let me think" line that is already playing finishes first. */
 async speak(text: string) {
  if (!state.available || !text.trim()) return;
  voice.unlock();
  if (kind === 'speech') { audio?.pause(); }
  const gen = ++generation; controller?.abort(); const c = new AbortController(); controller = c;
  const parts = splitSentences(text); if (!parts.length) return;
  speakOwner = gen;
  set({ phase: state.phase === 'playing' ? 'playing' : 'loading', error: '' });
  const fail = (e: unknown) => { if (gen !== generation || c.signal.aborted) return; kind = null; set({ phase: 'idle', error: (e as Error).message || '声音暂时不可用，文字还在。' }); };
  try {
   const fetched: Promise<Blob>[] = [], fetchOne = (i: number) => { const p = apiBlob('voice/tts', { text: parts[i] }, c.signal); p.catch(() => {}); fetched[i] = p; }; // pre-attach: an unprefetched rejection must not surface as unhandled
   fetchOne(0);
   for (let i = 0; i < parts.length; i++) {
    let blob: Blob;
    try { blob = await fetched[i]; } catch (e) { fail(e); return; } // sentence one failing keeps today's behaviour; later ones play what is already there, then stop
    if (gen !== generation) return;
    if (!i) { await waitForFiller(); if (gen !== generation) return; }
    release(); objectUrl = URL.createObjectURL(blob); prepareMeter(blob,gen);
    if (i + 1 < parts.length) fetchOne(i + 1); // prefetch the next sentence as this one starts: at most one request in flight
    const ended = waitEnded();
    if (!await play(objectUrl, gen, 'speech')) return; // autoplay refused: play() has already shown the message
    await ended;
    if (gen !== generation) return;
   }
   kind = null; set({ phase: 'idle' });
  } catch (e) { fail(e); } finally { if (speakOwner === gen) speakOwner = 0; }
 },
 async probe() {
  if (probed) return; probed = true;
  // 探测服务端语音能力：连不上就当没有语音，不要把失败当成「服务端挂了」。
  try { const data = await fetchJson<{voice?:{tts?:boolean;asr?:boolean}}>('/api/health',{timeoutMs:5000,fallbackMessage:'服务暂时连不上'}); set({ available: !!data?.voice?.tts, asr: !!data?.voice?.asr }); } catch { set({ available: false }); }
 },
};
export const getVoiceState = () => state;
/** 'filler' = a short pre-recorded reaction that a new touch may interrupt; 'speech' = a real reply or greeting. */
export const getVoiceKind = () => kind;
const subscribe = (l: () => void) => { listeners.add(l); return () => { listeners.delete(l); }; };
export function useVoice(): VoiceState & { actions: typeof voice } {
 const s = useSyncExternalStore(subscribe, () => state);
 useEffect(() => { void voice.probe(); }, []);
 return { ...s, actions: voice };
}
