import { useState } from 'react';
import { ArrowRight,Leaf,Pause,Send } from 'lucide-react';
import type { LearningUI } from '../../agents/useLearning';
import { retentionWindow,type MemoryRetention,type TaskPublicView } from '../../../shared/learning-contracts';
import { skillStatusLabels,evidenceKindLabels } from '../../../shared/assessment-labels';
import { GenerationPanel } from '../../learning/generation/GenerationPanel';
import { isGenerationKnowledgePoint } from '../../learning/generation';
import { useDevMode } from '../../agents/devMode';
import { ProblemList } from './home/ProblemList';
import { ChatHistory } from './home/ChatHistory';
import { ProfileView } from '../free-chat/ProfileView';
// G2 第二期挂载位：professional/* 归 ChatGPT，plan/* 归 zCode（见 交付/claude/CONTRACT-PHASE2.md）。
import { ProfessionalModeView } from '../professional/ProfessionalModeView';
import { ProfessionalReportView } from '../professional/ProfessionalReportView';
import { GrowthArchive } from '../professional/GrowthArchive';
import { MonthStageView } from '../plan/MonthStageView';
import { WeeklyTasksView } from '../plan/WeeklyTasksView';
import { RetestReminder } from '../plan/RetestReminder';
const actions:Record<string,string>={accept:'接受',lighter:'减量',reschedule:'改期',defer:'暂不开始',resume:'恢复'};
const statuses:Record<string,string>={scheduled:'已安排',proposed:'草案',paused:'暂停',completed:'完成',superseded:'已有后续版本'};
const names:Record<string,string>={'math-language':'数学语句与条件','counterexample':'反例与条件','negative-brackets':'去括号负号','like-terms':'合并同类项','fixed-variable-cost':'一次费用与变化费用','rotation-2d':'二维旋转'};
const date=(s:string)=>new Date(s).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false});
const pretty=(s:string)=>Object.entries({...names,...skillStatusLabels}).reduce((text,[key,value])=>text.replaceAll(key,value),s);
const swallow=(p:Promise<unknown>)=>{void p.catch(()=>{});};
const confidenceLabels:Record<string,string>={more_sure:'更有把握',about_same:'差不多',still_unsure:'仍不确定',prefer_not:'暂不回答'};
// G0: the service-mode bar and the Agent/tool trace are engineering views, shown only in developer mode.
export function LearningStatus({l}:{l:LearningUI}){const dev=useDevMode();if(!dev)return null;return <div className="learning-status" aria-live="polite" aria-label="服务模式"><Leaf size={15}/><span>{l.mode}</span><button className="text-button" onClick={()=>swallow(l.connect())}>重新连接</button></div>;}
export function LearningPages({l,page,navigate,onExploreDimension,safety=false,station,onStation}:{l:LearningUI;page:string;navigate:(page:string,tab?:string)=>void;onExploreDimension:(index:number)=>void;safety?:boolean;station?:string|false;onStation?:(module:string|false)=>void}){
 const dev=useDevMode();
 const [message,setMessage]=useState(''),[memoryText,setMemoryText]=useState(''),[editing,setEditing]=useState<string|null>(null),[scheduledDate,setScheduledDate]=useState(''),[reportId,setReportId]=useState(''),[planId,setPlanId]=useState(''),[preview,setPreview]=useState<{hash:string;attemptCount:number;warnings:string[]}|null>(null),[migration,setMigration]=useState(''),[retention,setRetention]=useState<MemoryRetention>('forever'),[growthTab,setGrowthTab]=useState<'profile'|'skills'|'records'>('profile');
 const v=l.view;
 if(!l.connected||!v)return <section className="info-paper"><h1>学习记录等待本地服务</h1><p>{dev?'新版记录保存在本机 SQLite。启动服务后重新连接，草稿仍在本机。':'暂时没能连接学习记录，草稿还在。请稍后重试。'}</p><button className="primary" onClick={()=>swallow(l.connect())}>重连本地服务</button></section>;
 const currentPlan=v.plans.at(-1)?.snapshot;
 const active=l.activeTask;
 const unfinishedInterview=v.interviews.some(i=>i.status!=='completed');
 const allowed=(task:typeof v.tasks[number])=>task.eligible&&(!(v.session?.mode==='exploration')||['理解','逻辑'].includes(task.primaryDimension)||['理解','逻辑'].every(d=>v.attempts.some(a=>a.sessionId===v.session?.id&&v.tasks.find(t=>t.id===a.taskId)?.primaryDimension===d)));

 const generate=()=>swallow(l.run('learning/generate',{timeBudgetMinutes:6}));
 const planAction=(action:string)=>{if(!v.proposal)return;swallow(l.run('learning/confirm',{proposalId:action==='defer'&&currentPlan?currentPlan.proposalId:v.proposal.id,expectedPreviousVersionId:currentPlan?.id??null,action,scheduledDate:action==='reschedule'?scheduledDate:null,reason:'学生明确选择'+({accept:'接受',lighter:'减量',reschedule:'改期',defer:'暂不开始',resume:'恢复'}[action]??action)}));};
 const headline=(eyebrow:string,title:string,note:string)=><div className="section-heading"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{note}</p></div>;
 const trace=dev&&<details className="evidence-details"><summary>查看 Agent 与工具轨迹</summary><p className="small">仅显示角色、模式、状态和引用；不显示密钥或内部思考。</p>{v.runs.slice(-12).map(run=><div className="learning-trace" key={run.id}><strong>{run.role==='planner'?'PlannerReporter':run.role==='assessor'?'Assessor':run.role==='generator'?'Generator':'Tutor'}</strong><span>{run.providerKind} · {run.status} · {run.rounds}轮 / {run.toolExecutions}工具</span></div>)}{v.toolCalls.slice(-20).map(t=><p className="small" key={t.id}>{t.name} · {t.status}{t.errorCode?' / '+t.errorCode:''} · {t.evidenceIds.length}个引用</p>)}</details>;
 return <div className="learning-pages">
 {l.busy&&<div className="notice" role="status">正在处理，草稿已保留。<button onClick={l.cancel}>取消等待</button></div>}
 {l.error&&<div className="notice error" role="alert">{dev?l.error:'这一步暂时没完成，已有记录和草稿还在，请稍后重试。'}</div>}
 {l.cache.pending&&!l.busy&&<div className="notice">保留了上次请求，重试不会重复记录。<button className="secondary" onClick={()=>swallow(l.retry())}>重试上次请求</button><button className="text-button" onClick={()=>l.update({pending:null})}>结束重试，保留已有记录</button></div>}
 {(page==='explore'||page==='growth')&&<>
 {headline(page==='explore'?'A SMALL WORLD TO EXPLORE':'GROW AT YOUR OWN PACE',page==='explore'?'每一种思考，都值得发现。':'每一点变化，都有来处。',page==='explore'?'不用证明什么。去几个地方，看看你怎样理解和解决问题。':'结果仅限已观察的子技能；待观察不代表能力弱。可以随时暂停。')}
 {v.paused&&page==='growth'&&!unfinishedInterview&&<div className="notice">学习已暂停，由你决定何时继续。<button className="secondary" disabled={l.busy||safety} onClick={()=>swallow(l.run('learning/start',{mode:'exploration'}))}>主动恢复本次学习</button></div>}
 {/* 星溪镇小游戏已深度融合进专业模式地图第一站「理解花园（理解能力）」。 */}
 {page==='explore'?<ProfessionalModeView l={l} navigate={navigate} safety={safety} onPractice={onExploreDimension} station={station} onStation={onStation}/>:<>
 <div className="growth-tabs" role="tablist" aria-label="成长视图切换">
  {([['profile','我的档案'],['skills','能力进展'],['records','报告与记录']] as const).map(([key,label])=><button key={key} type="button" role="tab" aria-selected={growthTab===key} className={growthTab===key?'active':''} onClick={()=>setGrowthTab(key)}>{label}</button>)}
 </div>
 {growthTab==='profile'&&<>
  <ProfileView/>
  <div className="growth-quick-links"><button className="secondary" onClick={()=>navigate('report','成长')}>学习观察报告</button><button className="secondary" onClick={()=>navigate('plan','成长')}>我的计划</button><button className="secondary" onClick={()=>navigate('memory')}>辅导偏好记忆</button></div>
 </>}
 {growthTab==='skills'&&<>
  <div className="growth-skills-grid">
  {['理解','逻辑','计算','建模','空间想象'].map(dim=><section className="info-paper growth-skill-card" key={dim}><h2>{dim}</h2>{v.assessment.skills.filter(s=>s.dimension===dim).map(s=><div className="learning-skill" key={s.id}><div className="growth-skill-top"><strong>{names[s.knowledgePointId]}</strong><span className="tag">{skillStatusLabels[s.status]}</span></div><p>{s.coverage}</p>{s.recentDifficulty&&<p>最近一次仍有困难，此前成功继续保留。</p>}{isGenerationKnowledgePoint(s.knowledgePointId)&&<details><summary>针对这个环节出一道新题</summary><GenerationPanel l={l} knowledgePointId={s.knowledgePointId} purpose="practice" navigate={navigate} safety={safety}/></details>}<details><summary>观察范围与待了解</summary>{s.unknowns.map((u,i)=><p className="small" key={i}>{u}</p>)}</details></div>)}</section>)}
  </div>
  <ProblemList l={l} navigate={navigate}/>
 </>}
 {growthTab==='records'&&<>
  <GrowthArchive l={l} navigate={navigate}/>
  {v.progressCards.length>0&&<section className="info-paper progress-cards"><h2>进步卡</h2><p className="small muted">你确认过的学习记录，不是评分。</p>
   {[...v.progressCards].reverse().map(c=>{const ep=c.episodeId?v.episodes.filter(e=>e.id===c.episodeId).at(-1):undefined;const helped=!!ep&&ep.helpLevelsUsed.length>0;
    return <div className="progress-card-record" key={c.id}><small>{date(c.confirmedAt)}{ep?.studentSolvedAt?(helped?' · 提示后完成':' · 自己完成'):''}</small>
     {([['今天的小突破',c.breakthrough],['这次有用的方法',c.method],['下次想试试',c.nextTry]] as const).map(([label,value])=><p key={label}><strong>{label}：</strong>{value??'跳过'}</p>)}
     <p className="small">信心自评：{c.confidence?confidenceLabels[c.confidence]:'未记录'}</p>
    </div>;})}
  </section>}
  {v.summaries.length>0&&<section className="info-paper conversation-summaries"><h2>对话小结</h2><p className="small muted">聊天观察，待专业模式确认，不是评分。</p>
   {[...v.summaries].reverse().map(s=><details key={s.id}><summary>{date(s.createdAt)} · {s.topics.join('、')||'聊了聊'}</summary>
    {/* 当时说了什么：对话回放（2026-10-24），原文按轮成对保存在本地服务的 chatLog 里 */}
    {v.chatLog.filter(m=>m.sessionId===s.sessionId).map(m=><p className="chat-line" key={m.id}><strong>{m.role==='user'?'我':'小N'}</strong>{m.content}</p>)}
    {s.observationIds.map(oid=>v.observations.find(o=>o.id===oid)).flatMap(o=>o?[o]:[]).map(o=><p key={o.id}><span className="tag">{o.dimension} · {o.sceneId?'生活话题 · ':''}待核实</span>「{o.quote}」{o.note}</p>)}
    {s.changes.length>0&&<><h3>和上次比</h3>{s.changes.map((c,i)=><p key={i}>{c}</p>)}</>}
    <h3>可以试试</h3>{s.planSuggestions.map((c,i)=><p key={i}>{c}</p>)}
   </details>)}
  </section>}
  <ChatHistory l={l} navigate={navigate} includeCurrent={false} onlyWithoutSummary/>
  <div className="quick-replies"><button onClick={()=>navigate('report','成长')}>学习观察报告</button><button onClick={()=>navigate('plan','成长')}>查看我的计划</button><button onClick={()=>navigate('review','成长')}>阶段回顾</button><button onClick={()=>navigate('memory')}>我的学习记忆</button></div>
 </>}
 </>}
 </>}
 {page==='task'&&<>
 {l.candidate?<section className="info-paper"><span className="eyebrow">YOUR CHOICE</span><h1>要从这一步开始吗？</h1><h2>{l.candidate.title}</h2><p>约 {l.candidate.estimatedMinutes} 分钟。确认后才展示题面并记录暴露；已有记录不会被覆盖。</p><button className="primary wide" disabled={l.busy||safety||!v.tasks.find(t=>t.id===l.candidate?.id)?.eligible} onClick={()=>swallow(l.confirmCandidate())}>确认开始这道题</button>{!v.tasks.find(t=>t.id===l.candidate?.id)?.eligible&&<div className="notice">这道题需要先尝试先修任务。{v.tasks.filter(t=>l.candidate?.prerequisites.some(k=>t.knowledgePoints.includes(k))&&t.variantKind==='observation').map(t=><button key={t.id} className="secondary" onClick={()=>l.choose(t)}>先尝试{t.title}</button>)}</div>}<button className="text-button" onClick={()=>{l.setCandidate(null);navigate('explore','探索');}}>现在先不看</button></section>:active&&!v.exposures.some(e=>e.taskId===active.id&&e.sessionId===v.session?.id&&e.kind==='task')?<section className="info-paper"><h1>题目打开尚未完成</h1><p>请用上方保留的请求重试。确认记录保存后才展示题面。</p></section>:active?<>
 {headline(active.primaryDimension,active.title,'先写下自己的尝试。需要提示也没关系，会与独立完成分别记录。')}
 {v.paused&&<div className="notice">当前场次暂停。<button disabled={l.busy||safety} onClick={()=>swallow(l.run('learning/start',{mode:v.session?.mode??'support'}))}>主动恢复</button></div>}
 <section className="task-card"><p className="learning-question">{active.question}</p>{active.visual&&<SpatialTask task={active}/>}{active.choices.map(c=><button className="learning-choice" key={c} disabled={l.busy||v.paused} onClick={()=>l.update({drafts:{...l.cache.drafts,[active.id]:c.split(':')[0]}})}>{c}</button>)}
 <label className="field">我的作答与过程<textarea aria-label="我的作答与过程" rows={4} value={l.cache.drafts[active.id]??''} onChange={e=>l.update({drafts:{...l.cache.drafts,[active.id]:e.target.value}})} placeholder="可以写结果，另起一行说明理由"/></label>
 <button className="primary wide" disabled={l.busy||v.paused||safety||!l.cache.drafts[active.id]?.trim()} onClick={()=>{if(!v.session)return;swallow(l.run('learning/submit',{sessionId:v.session.id,taskId:active.id,taskVersion:active.version,value:l.cache.drafts[active.id],reviewItemId:l.cache.reviewLink?.id??null,reviewRevision:l.cache.reviewLink?.revision??null}));}}>保存尝试并核对</button>
 <div className="quick-replies"><button disabled={l.busy||v.paused||safety} onClick={()=>v.session&&swallow(l.run('learning/hint',{sessionId:v.session.id,taskId:active.id,taskVersion:active.version,level:1}))}>看一级提示</button><button onClick={()=>swallow(l.pause())}><Pause size={15}/>先暂停</button></div>
 {v.exposures.filter(e=>e.taskId===active.id&&e.kind==='hint').slice(-1).map(h=><p className="notice" key={h.id}>提示：{h.contentSnapshot}</p>)}
 </section>
 {v.attempts.filter(a=>a.taskId===active.id).map(a=>{const grade=v.gradings.filter(g=>g.attemptId===a.id).at(-1);return <section className="info-paper" key={a.id}><span className="tag">{evidenceKindLabels[a.classification.kind]}</span><h3>{grade?.verdict==='correct'?'这次核对正确':grade?.verdict==='incorrect'?'先停在这一步，看看依据':'已保存，评分待核查'}</h3><pre>{a.value}</pre><p>{a.classification.reason}</p><small>{a.sourceTime.occurredAt?date(a.sourceTime.occurredAt):'旧发生时间未知'}</small>{(!grade||grade.verdict==='needs_review')&&<button className="secondary wide" disabled={l.busy} onClick={()=>swallow(l.run('learning/grade',{attemptId:a.id}))}>重试分析已保存作答</button>}{grade&&grade.verdict!=='needs_review'&&<details><summary>这次评分需要核查？</summary><p>只用已保存原作答与可信题库重新核验，保留原评分和修订依据。</p><button disabled={l.busy} onClick={()=>swallow(l.run('learning/grade',{attemptId:a.id,expectedGradingId:grade.id}))}>重新核查这次评分</button></details>}</section>;})}
 {active.knowledgePoints.filter(isGenerationKnowledgePoint).slice(0,1).map(k=>v.attempts.some(a=>a.taskId===active.id)&&<GenerationPanel key={k} l={l} knowledgePointId={k} purpose="practice" navigate={navigate} safety={safety}/>)}
 <div className="quick-replies"><button onClick={()=>navigate('report','成长')}>查看作答证据</button><button onClick={()=>navigate('plan','成长')}>整理下一步计划</button><button onClick={()=>navigate('explore','探索')}>由我再选一道</button></div>{trace}
 </>:<div className="info-paper"><h1>先选择想尝试的内容</h1><button className="primary" onClick={()=>navigate('explore','探索')}>去探索</button></div>}
 </>}
 {page==='report'&&<>
 {headline('THIS TIME, AT YOUR PACE','看看这次的发现。','按模块看看本次观察、依据原话和可以尝试的方法。')}
 <ProfessionalReportView l={l} navigate={navigate}/>
 {dev&&<details className="evidence-details"><summary>详细证据（原学习观察报告）</summary>
 <button className="primary wide" disabled={l.busy} onClick={generate}>根据当前证据生成报告与计划草案</button>
 <label className="field">报告历史<select value={reportId||v.reports.at(-1)?.snapshot.id||''} onChange={e=>setReportId(e.target.value)}><option value="">选择报告</option>{v.reports.map((r,i)=><option key={r.snapshot.id} value={r.snapshot.id}>第{i+1}份 · {date(r.snapshot.createdAt)}{r.basisRevised?' · 依据已修订':''}</option>)}</select></label>
 {(()=>{const r=v.reports.find(r=>r.snapshot.id===reportId)??v.reports.at(-1);return r?<section className="info-paper"><h2>观察快照 · 证据版本 {r.snapshot.evidenceRevision}</h2>{r.basisRevised&&<p className="notice">此报告的部分依据已修订，原快照保留。请查看新版本。</p>}{r.snapshot.statements.map((s,i)=><div className="learning-statement" key={i}><span className="tag">{{fact:'事实',inference:'推断',unknown:'未知'}[s.kind]}</span><p>{pretty(s.text)}</p>{s.evidenceIds.length>0&&<details><summary>展开 {s.evidenceIds.length} 条原始依据</summary>{s.evidenceIds.map(id=>{const e=v.evidence.find(e=>e.id===id),a=v.attempts.find(a=>a.id===e?.attemptId);return <div className="learning-evidence" key={id}><strong>{names[e?.knowledgePointId??'']??id}</strong><p>{v.tasks.find(t=>t.id===a?.taskId)?.question??a?.taskId}</p><pre>{a?.value}</pre><p>定位引用：{e?.quote}（{e?.location.start}–{e?.location.end}）</p><p>{e?.explanation}</p><small>{e?.source} · {a?.classification.reason} · 提交前提示 {a?.hintSnapshot.length??0} 条</small></div>;})}</details>}</div>)}<h3>本版变化</h3>{r.snapshot.changes.map((c,i)=><p key={i}>{pretty(c)}</p>)}{r.snapshot.coverage.map((c,i)=><p className="small" key={i}>{c}</p>)}</section>:<p className="notice">还没有报告。无记录时只会给出待观察项和可选建议。</p>;})()}
 <button className="secondary wide" onClick={()=>navigate('plan','成长')}>看看下一步计划</button></details>}{trace}
 </>}
 {(page==='plan'||page==='today')&&<>
 {headline(page==='plan'?'ONE SMALL STEP':'TODAY, AT YOUR PACE',page==='plan'?'下一步，由你来决定。':'今天，按自己的节奏。','计划草案来自当前具体证据。接受、减量、改期和暂不开始都会保存真实版本；没有真实通知。')}
 {page==='plan'&&<MonthStageView l={l} navigate={navigate} safety={safety}/>}
 {page==='today'&&<><RetestReminder reminder={v.retestReminder} where="today" l={l} navigate={navigate}/><WeeklyTasksView l={l} navigate={navigate} safety={safety}/></>}
 {page==='plan'&&<><button className="secondary wide" disabled={l.busy} onClick={generate}>按当前证据重新整理草案</button>{v.proposal&&<section className="info-paper"><span className="tag">待学生确认的草案</span><h2>{pretty(v.proposal.goal)}</h2>{v.proposal.items.map(i=><p key={i.id}>{i.scheduledDate} · {pretty(i.goal)} · {i.estimatedMinutes}分钟</p>)}{v.proposal.statements.map((s,i)=><p className="small" key={i}>{pretty(s.text)}</p>)}<div className="quick-replies"><button disabled={l.busy} onClick={()=>planAction('accept')}>接受这份计划</button><button disabled={l.busy} onClick={()=>planAction('lighter')}>减量一点</button><button disabled={l.busy} onClick={()=>planAction('defer')}>暂不开始</button></div><label className="field">改期日期<input type="date" value={scheduledDate} min={v.now.slice(0,10)} onChange={e=>setScheduledDate(e.target.value)}/></label><button className="secondary" disabled={!scheduledDate||l.busy} onClick={()=>planAction('reschedule')}>确认改期</button></section>}
 <label className="field">计划版本<select value={planId||currentPlan?.id||''} onChange={e=>setPlanId(e.target.value)}><option value="">尚无确认版本</option>{v.plans.map(p=><option key={p.snapshot.id} value={p.snapshot.id}>版本{p.snapshot.version} · {actions[p.snapshot.confirmation.action]}{p.basisRevised?' · 依据已修订':''}</option>)}</select></label>{(()=>{const h=v.plans.find(p=>p.snapshot.id===planId)??v.plans.at(-1);return h&&<section className="info-paper"><h2>已确认版本 {h.snapshot.version}</h2><p>{pretty(h.snapshot.goal)}</p><p>{h.snapshot.confirmation.reason}</p>{h.basisRevised&&<p>依据已修订；这个历史版本保留。</p>}{h.snapshot.items.map(i=><p key={i.id}>{i.scheduledDate} · {pretty(i.goal)} · {statuses[i.status]??i.status}</p>)}</section>;})()}</>}
 {page==='today'&&currentPlan&&<section className="info-paper"><span className="tag">学生确认的当前目标 · 版本 {currentPlan.version}</span><h2>{pretty(currentPlan.goal)}</h2>{currentPlan.items.filter(i=>i.scheduledDate===new Date(v.now).toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'})).map(i=>{const progress=v.reviews.find(r=>r.knowledgePointId===i.knowledgePointId&&r.planVersionId===currentPlan.id);const t=i.task?v.tasks.find(t=>t.id===i.task?.taskId):v.tasks.find(t=>t.knowledgePoints.includes(i.knowledgePointId)&&v.attempts.some(a=>a.taskId===t.id));const done=i.task&&v.attempts.some(a=>a.taskId===i.task?.taskId&&a.sourceTime.recordedAt>=currentPlan.confirmation.confirmedAt);return <div className="learning-statement" key={i.id}><h3>{pretty(i.goal)}</h3><p>{i.estimatedMinutes}分钟 · {done?'已有真实尝试':progress?.status==='completed'?'本轮完成':v.paused||i.status==='paused'?'已暂停':'等待自主开始'}</p>{t&&!done&&!v.paused&&currentPlan.confirmation.action!=='defer'&&<button className="secondary wide" disabled={l.busy||safety||!t.eligible} onClick={()=>{l.choose(t,'support');l.update({reviewLink:null});navigate('task');}}>{i.task?'确认后开始这个任务':'回顾一个已有步骤（不算未见检验）'}</button>}</div>;})}<p className="small">错过的安排不扣能力，也不集中堆积。下方复习队列只保留每个知识点的当前状态。</p></section>}
 {page==='today'&&!currentPlan&&<div className="notice">还没有接受计划。<button onClick={()=>navigate('plan','成长')}>查看可选建议</button></div>}
 {(v.paused||currentPlan?.confirmation.action==='defer')&&<p className="notice">任务已暂停，不催促、不自动开题。<button disabled={l.busy||safety} onClick={()=>swallow(l.run('learning/start',{mode:'review'}).then(()=>currentPlan?l.run('learning/confirm',{proposalId:currentPlan.proposalId,expectedPreviousVersionId:currentPlan.id,action:'resume',scheduledDate:null,reason:'学生主动恢复，避免任务堆积'}):Promise.resolve()))}>我想主动恢复</button></p>}
 <h2>复习队列</h2>{v.reviews.filter(i=>i.status!=='superseded').map(i=>{const due=i.dueAt<=v.now;const unseen=v.tasks.find(t=>t.knowledgePoints.includes(i.knowledgePointId)&&allowed(t)&&!v.exposures.some(e=>e.taskId===t.id)&&!v.attempts.some(a=>a.taskId===t.id));const original=v.tasks.find(t=>t.knowledgePoints.includes(i.knowledgePointId)&&v.attempts.some(a=>a.taskId===t.id));const select=(task:TaskPublicView)=>{l.choose(task,'review');l.update({reviewLink:{id:i.id,revision:i.revision}});navigate('task');};return <section className="info-paper" key={i.id}><span className="tag">{i.status==='paused'?'暂停':i.status==='completed'?'本轮完成':due?'已到期':'待到期'} · 阶段 {i.stage}</span><h3>{names[i.knowledgePointId]}</h3><p>{date(i.dueAt)}</p><p>{i.reason}</p>{i.status==='active'&&due&&!v.paused&&currentPlan?.confirmation.action!=='defer'&&<>{unseen?<><button className="primary wide" disabled={l.busy||safety} onClick={()=>select(unseen)}>由我确认一道未见复习题</button>{isGenerationKnowledgePoint(i.knowledgePointId)&&<details><summary>或者根据这个环节出一道新题</summary><GenerationPanel l={l} knowledgePointId={i.knowledgePointId} purpose="review" review={{id:i.id,revision:i.revision}} navigate={navigate} safety={safety}/></details>}</>:<><p className="notice">未见题库不足，不能假装进行新题检验。</p>{isGenerationKnowledgePoint(i.knowledgePointId)&&<GenerationPanel l={l} knowledgePointId={i.knowledgePointId} purpose="review" review={{id:i.id,revision:i.revision}} navigate={navigate} safety={safety}/>}</>}{original&&<button className="secondary wide" disabled={l.busy||safety} onClick={()=>select(original)}>原题回顾（不算未见检验）</button>}</>}</section>;})}
 {!v.reviews.length&&<p className="notice">暂无到期队列。确认计划且取得可信作答后才安排真实复习。</p>}
 </>}
 {page==='review'&&<>
 {headline('REAL CHANGES, OVER TIME','看看新的变化。','原题修改、提示后完成和未见题独立完成各自保留。同一天反复答题不能证明跨次稳定。')}
 {v.attempts.map(a=><section className="info-paper" key={a.id}><span className="tag">{evidenceKindLabels[a.classification.kind]}</span><h3>{v.tasks.find(t=>t.id===a.taskId)?.title??a.taskId}</h3><pre>{a.value}</pre><p>{a.classification.reason}</p><p className="small">{a.classification.learningDate??'旧学习日期未知'} · {a.classification.novelty==='unseen'?'未见题':a.classification.novelty==='seen'?'已见题':'暴露未知'} · {a.hintSnapshot.length}条提示</p></section>)}{!v.attempts.length&&<p>还没有作答。不把未开始理解为能力弱。</p>}<button className="secondary wide" onClick={()=>navigate('report','成长')}>报告与历史</button>{trace}
 </>}
 {page==='memory'&&<>
 {headline('YOUR CHOICE, ALWAYS','记住什么，由你决定。','可选偏好与必要学习记录、已确认计划分开。关闭、停用或删除后，不再进入随后的模型上下文；已发送内容无法追溯撤回。')}
 <label className="check-row"><input type="checkbox" checked={v.optionalMemory} disabled={l.busy} onChange={()=>swallow(l.run('consent',{optionalMemory:!v.optionalMemory}))}/><span>允许可选长期辅导偏好</span></label>
 <label className="field">{editing?'更正这条偏好':'我主动保留的偏好'}<textarea value={memoryText} onChange={e=>setMemoryText(e.target.value)} placeholder="例如：解释时一次只讲一步"/></label><div className="quick-replies" role="group" aria-label="记多久">{([['forever','一直记得'],['7d','记 7 天'],['30d','记 30 天']] as const).map(([key,label])=><button key={key} type="button" aria-pressed={retention===key} onClick={()=>setRetention(key)}>{label}</button>)}</div>
 <button className="primary wide" disabled={l.busy||!v.optionalMemory||!memoryText.trim()} onClick={()=>swallow((editing?l.run('learning/memory-correct',{memoryId:editing,text:memoryText,retention}):l.run('memories',{text:memoryText,source:'student_explicit',purpose:'tutoring',...retentionWindow(retention,v.now)})).then(()=>{setEditing(null);setMemoryText('');setRetention('forever');}))}>{editing?'保存更正并停止旧条目':'确认保留这条偏好'}</button>
 {v.memories.map(m=><section className="info-paper" key={m.id}><span className="tag">{m.active?'有效条目':'已停止使用'}{!v.optionalMemory?' · 当前记忆关闭':''}</span><p>{m.text}</p><small>来源：学生主动确认 · {date(m.createdAt)}{m.expiresAt?(m.expiresAt<=v.now?' · 已到期，不再进入对话':' · 记到 '+date(m.expiresAt)):''}</small>
  {m.active&&m.reviewAt&&m.reviewAt<=v.now&&<div className="notice memory-review">这条记住满 30 天了，还适用吗？到期待复核的记忆暂时不进入对话。<button className="secondary" disabled={l.busy||!v.optionalMemory} onClick={()=>swallow(l.run('learning/memory-correct',{memoryId:m.id,text:m.text,retention:'forever'}))}>还适用</button><button className="text-button" disabled={l.busy} onClick={()=>swallow(l.run('memories/state',{memoryId:m.id,action:'stop'}))}>不适用了</button></div>}<div className="quick-replies"><button disabled={l.busy||!v.optionalMemory} onClick={()=>{setEditing(m.id);setMemoryText(m.text);}}>更正</button><button disabled={l.busy||!m.active} onClick={()=>swallow(l.run('memories/state',{memoryId:m.id,action:'stop'}))}>停止使用</button><button disabled={l.busy} onClick={()=>swallow(l.run('memories/state',{memoryId:m.id,action:'delete'}))}>删除偏好</button></div></section>)}
 <details className="info-paper"><summary>导入旧浏览器作答（先备份与预览）</summary><p>只导入原始尝试。旧聊天、图片、计划和记忆继续保留在原浏览器，不作为新版事实。旧时间及暴露未知不补造。</p><button className="secondary" disabled={l.busy} onClick={()=>{const source=localStorage.getItem('xiaon-progress-v1')??'';const blob=new Blob([source],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='xiaon-legacy-backup.json';a.click();URL.revokeObjectURL(url);setMigration(source);swallow(l.run<typeof preview>('import/preview',{source},{persist:false}).then(setPreview));}}>下载旧记录备份并预览</button>{preview&&<><p>预览：{preview.attemptCount}次尝试</p>{preview.warnings.map((w,i)=><p className="small" key={i}>{w}</p>)}<button className="primary" disabled={l.busy} onClick={()=>swallow(l.run<{imported:number}>('import',{source:migration,previewHash:preview.hash,scope:'attempts_only'}).then(r=>l.setError(`导入完成：新增 ${r.imported} 次尝试；重复记录已去重。`)))}>确认只导入这些尝试</button></>}</details>
 <p className="notice">删除偏好不会删除作答证据。要清除 SQLite、草稿与旧本机记录，请到设置选择“重置整个演示”。</p>{trace}
 </>}
 </div>;
}
function SpatialTask({task}:{task:TaskPublicView}){if(!task.visual)return null;const v=task.visual;const plot=(points:[number,number][])=>points.map(([x,y])=>`${60+x*10},${60-y*10}`).join(' ');return <div className="learning-spatial">{[{label:'原图',points:v.points},...v.options].map(o=><figure key={o.label}><svg viewBox="0 0 120 120" role="img" aria-label={o.label+'坐标图'}><path d="M5 60H115M60 5V115" stroke="#b6bfb4"/><polyline points={plot(o.points)} stroke="#3e6956" strokeWidth="3" fill="none"/><circle cx={60+v.center[0]*10} cy={60-v.center[1]*10} r="3" fill="#cf9b42"/></svg><figcaption>{o.label}</figcaption></figure>)}</div>;}
